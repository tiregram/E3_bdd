DELIMITER $$

CREATE FUNCTION is_today_sunday()
RETURNS VARCHAR(255)
BEGIN
   DECLARE message VARCHAR(255) DEFAULT 'No';
   IF DAYOFWEEK(NOW()) = 1 THEN
      SET message = 'Yes';
   END IF;
   RETURN message;
END $$

CREATE FUNCTION what_is_today()
RETURNS VARCHAR(255)
BEGIN
   DECLARE message VARCHAR(255);
   IF DAYOFWEEK(NOW()) = 1 THEN
      SET message = 'Sunday';
   ELSEIF DAYOFWEEK(NOW()) = 2 THEN
      SET message = 'Monday';
   ELSEIF DAYOFWEEK(NOW()) = 3 THEN
      SET message = 'Tuesday';
   ELSEIF DAYOFWEEK(NOW()) = 4 THEN
      SET message = 'Wednesday';
   ELSEIF DAYOFWEEK(NOW()) = 5 THEN
      SET message = 'Thursday';
   ELSEIF DAYOFWEEK(NOW()) = 6 THEN
      SET message = 'Friday';
   ELSEIF DAYOFWEEK(NOW()) = 7 THEN
      SET message = 'Saturday';
   END IF;
   RETURN message;
END $$

DELIMITER ;