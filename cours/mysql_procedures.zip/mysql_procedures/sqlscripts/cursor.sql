DELIMITER $$

CREATE PROCEDURE check_age_with_cursor()
BEGIN
   DECLARE f VARCHAR(255);
   DECLARE a INT;

   DECLARE c CURSOR FOR
      SELECT first_name, age FROM person;

   OPEN c;
   total: LOOP

      FETCH c INTO f, a;
      IF a > 60 THEN
         SELECT f AS FirstName, a AS Age, 'is Old' AS AgeCategory;
      ELSE
         SELECT f AS FirstName, a AS Age, 'is Young' AS AgeCategory;
      END IF;
    
   END LOOP total;
   CLOSE c;

END $$     

DELIMITER ;
