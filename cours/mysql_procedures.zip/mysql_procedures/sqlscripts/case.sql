DELIMITER $$

CREATE FUNCTION what_is_today_using_case()
RETURNS VARCHAR(255)
BEGIN
   DECLARE message VARCHAR(255);
   CASE DAYOFWEEK(NOW())
   WHEN 1 THEN
      SET message = 'Sunday';
   WHEN 2 THEN
      SET message = 'Monday';
   WHEN 3 THEN
      SET message = 'Tuesday';
   WHEN 4 THEN
      SET message = 'Wednesday';
   WHEN 5 THEN
      SET message = 'Thursday';
   WHEN 6 THEN
      SET message = 'Friday';
   WHEN 7 THEN
      SET message = 'Saturday';
   END CASE;
   RETURN message;
END $$

DELIMITER ;