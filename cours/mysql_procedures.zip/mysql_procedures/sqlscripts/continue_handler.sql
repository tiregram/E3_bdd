/* Start clean */
DROP PROCEDURE IF EXISTS drop_table_error;
DROP PROCEDURE IF EXISTS drop_table_continue_handler;

DELIMITER $$

/* An example procedure in which processing is halted due to an error */
CREATE PROCEDURE drop_table_error()
BEGIN

   SELECT 'Starting procedure' as message;
   DROP TABLE non_existent_table;
   SELECT 'Ending procedure' as message;
   
END $$     

/* An example procdure in which processing continues due to CONTINUE HANDLER */
CREATE PROCEDURE drop_table_continue_handler()
BEGIN

   /* Declare continue handler for non existent table error condition */
   DECLARE CONTINUE HANDLER FOR 1051
   BEGIN
      SELECT 'You are trying to drop a table that is non-existent!' AS message1;
   END;

   SELECT 'Starting procedure' as message;
   /* You are dropping a table that does not exist. 
    * This should cause an 1051 error condition.
    * Because there is CONTINUE HANDLER for 1051
    * error condition, the next statement should
    * be executed.
    */
   DROP TABLE non_existent_table;
   SELECT 'Ending procedure' as message2;
    
END $$     

DELIMITER ;
