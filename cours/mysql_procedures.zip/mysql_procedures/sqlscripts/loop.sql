DELIMITER $$

CREATE FUNCTION factorial_loop(num INT UNSIGNED)
RETURNS INT
BEGIN
   DECLARE result INT DEFAULT 1;

   myloop: LOOP
     IF num > 0 THEN
         SET result = result * num;
         SET num = num - 1;
      ELSE
         LEAVE myloop;
      END IF;
   END LOOP myloop;

   RETURN result;
END $$

CREATE FUNCTION factorial_while(num INT UNSIGNED)
RETURNS INT
BEGIN
   DECLARE result INT DEFAULT 1;

   myloop: WHILE num > 0 DO
      SET result = result * num;
      SET num = num - 1;
   END WHILE myloop;

   RETURN result;
END $$

CREATE FUNCTION factorial_repeat(num INT UNSIGNED)
RETURNS INT
BEGIN
   DECLARE result INT DEFAULT 1;

   myloop: REPEAT
      SET result = result * num;
      SET num = num - 1;
      UNTIL num <= 0
   END REPEAT myloop;

   RETURN result;
END $$

DELIMITER ;