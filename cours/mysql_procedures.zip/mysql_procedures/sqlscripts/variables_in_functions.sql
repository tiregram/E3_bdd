DELIMITER $$

CREATE FUNCTION compute_circle_area2(radius INT)
RETURNS FLOAT
BEGIN
   DECLARE my_pi FLOAT DEFAULT PI();
   RETURN my_pi * radius * radius;
END $$

DELIMITER ;


