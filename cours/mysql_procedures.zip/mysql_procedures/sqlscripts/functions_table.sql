DELIMITER $$

CREATE FUNCTION insert_person(p_id SMALLINT, f_name VARCHAR(45), l_name VARCHAR(45), age INT)
RETURNS INT
BEGIN
   INSERT INTO person (person_id, first_name, last_name, age)
   VALUES
   (p_id, f_name, l_name, age);
   RETURN 1;
END $$

CREATE FUNCTION delete_person(p_id SMALLINT)
RETURNS INT
BEGIN
  DELETE FROM person WHERE person_id = p_id;  
  RETURN 1;
END $$

DELIMITER ;



