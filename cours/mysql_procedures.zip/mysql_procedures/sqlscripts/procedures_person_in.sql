DELIMITER $$

CREATE PROCEDURE get_person(IN p_id SMALLINT)
BEGIN
   SELECT * FROM person
   WHERE person_id = p_id;
END $$

CREATE PROCEDURE get_person2(IN p_id SMALLINT, IN p_age INT)
BEGIN
   SELECT * FROM person
   WHERE person_id > p_id AND age > p_age;
END $$

DELIMITER ;
